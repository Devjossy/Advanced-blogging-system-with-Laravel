<?php $__env->startSection('content'); ?>
     
     <a href="/todos">Visit my todos</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>