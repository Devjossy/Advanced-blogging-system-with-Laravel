<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = App\User::create([
            'name' => 'Joshua',
            'email' => 'joshua@gmail.com',
            'password' => bcrypt('password'),
            'admin' => 1
        ]);

        App\Profile::create([
            'user_id' => $user->id,
            'avatar' => 'uploads/avatars/a6.png',
            'about' => 'The guy who has this profile has a lot to do in the ecosystem of his generation',
            'facebook' => 'facebook.com',
            'youtube' => 'youtube.com'
        ]);
    }
}
